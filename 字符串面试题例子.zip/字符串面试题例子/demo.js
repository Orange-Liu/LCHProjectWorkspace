function count(){
    //要统计的字符串
    var str = "asdjfhlasdasvfweguywbahsdbvkjajgsfhgasdfajsgdfauywyeawjf";
    document.write("原始字符串 ： " + str +"<br>");
    //定义一个空对象，用来存储统计数据
    var json = {};
    //循环遍历这个字符串（遍历的是字符串中每个字符的索引，这个你应该知道吧^_^）
    //用stringObj.charAt(index)函数返回指定位置的字符
    for(var i = 0; i < str.length; i++){
        //先判断json对象中是否存在这个字符
        if(!json[str.charAt(i)]){
            //如果不存在，将该字符存储到json对象中，并给该字符赋值为1
            //js对象中存储的是key-value键值对，key是字符串中的字符，value是出现次数，格式：{key:value},例如：{"a":9}
            json[str.charAt(i)] = 1;
        }else{
            //如果存在，则将该对象中该字符的值加1
            json[str.charAt(i)] ++;
        }
    }
    //此处打印出来的是字符串中重复字符出现次数的统计结果
    console.log(json);
    //定义一个变量，接受最大的值
    var max = 0;
    //定义一个变量，接受最大值对应的字符
    var maxKey = "";
    //遍历对象，key表示json对象中的每个key
    for(var key in json){
        //遍历取出值（value）与max比较
        if(json[key] > max){
            //如果取出的值大于max，说明max不是最大的，就将取出的值赋值给max
            max = json[key];
            //记录当前的key值
            maxKey = key;
        }
    }
    //循环结束，则打印出来的就是最大值对应的字符和出现的次数了
    document.write("出现字符最多的是 ： " + maxKey + " = " + max);
}